README
===========================

最简单的一个可运行的RESTful API

### 运行
```bash
mvn spring-boot:run
```
启动后，可通过http://localhost:8080/tvseries 来查看结果。

