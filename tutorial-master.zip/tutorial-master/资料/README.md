参考资料
--------

此目录中的PPT和PDF是制作教学视频[用Spring Boot编写RESTful API http://study.163.com/course/courseMain.htm?courseId=1005213034](http://study.163.com/course/courseMain.htm?courseId=1005213034) 时使用的资料，
和视频相比不是很完整，视频有些是多个PPT和录屏拼接而成的。

虽无法取代看视频的效果，但看完视频后再查找资料时使用可能会比较便捷，供大家参考。


