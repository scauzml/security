package cn.devmgr.tutorial;

public class ClockMessage {
    private String message;

    
    public ClockMessage() {
    }
    
    public ClockMessage(String message) {
        this.message = message;
    }
    
    
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    

}
